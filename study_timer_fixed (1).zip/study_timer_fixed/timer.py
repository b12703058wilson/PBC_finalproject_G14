# timer.py — 讀書 session 邏輯（精簡版）
#
# 保留：EXP 計算、好感度計算、干擾警告門檻
# 移除：StudySession 類別（已整合進 timer_page.py）、
#        番茄鐘/自訂模式切換、目標時間、久未讀書提醒等 UI 無關邏輯

from datetime import datetime

# ════════════════════════════════════════════════
# 系統常數
# ════════════════════════════════════════════════

DAILY_EXP_CAP               = 200   # 每日 EXP 上限
DISTRACTION_WARNING_MINUTES = 10    # 干擾提醒門檻（分鐘）
AFF_MAX                     = 100   # 好感度上限


# ════════════════════════════════════════════════
# EXP 計算
# ════════════════════════════════════════════════

def calculate_exp(actual_secs, daily_exp_so_far=0):
    """
    計算本次讀書可獲得的 EXP。

    規則：
    - 讀書 1 分鐘獲得 1 EXP，無加成。
    - 每日 EXP 不超過 DAILY_EXP_CAP（200）。
    """
    actual_min    = actual_secs / 60
    remaining_cap = max(0, DAILY_EXP_CAP - daily_exp_so_far)
    return round(min(actual_min, remaining_cap), 2)


# ════════════════════════════════════════════════
# 好感度計算
# ════════════════════════════════════════════════

def calculate_affection_gain(actual_secs):
    """
    計算本次讀書可增加的好感度。

    規則：
    - 每連續讀書 15 分鐘增加 1 點好感度。
    - 單次讀書超過 60 分鐘後，超過部分以 2 倍計算。
    - 好感度增加量不超過 AFF_MAX。
    """
    actual_min = actual_secs / 60
    BONUS_THRESHOLD = 60

    if actual_min <= BONUS_THRESHOLD:
        affection = actual_min / 15
    else:
        before = BONUS_THRESHOLD / 15
        after  = (actual_min - BONUS_THRESHOLD) / 15 * 2
        affection = before + after

    return round(min(affection, AFF_MAX), 2)


# ════════════════════════════════════════════════
# 干擾警告判斷
# ════════════════════════════════════════════════

def needs_distraction_warning(distraction_minutes):
    """
    判斷干擾時間是否超過提醒門檻。

    Parameters
    ----------
    distraction_minutes : float
        累積干擾分鐘數。

    Returns
    -------
    bool
        True：需要跳出干擾提醒。
    """
    return distraction_minutes > DISTRACTION_WARNING_MINUTES
