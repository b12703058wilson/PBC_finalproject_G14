# pages/stat_page.py — 統計頁
# 圖表樣式使用組員 plot_manager.py 的設計，嵌入 tkinter 視窗

import tkinter as tk
import matplotlib
matplotlib.use("TkAgg")
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
import seaborn as sns
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config import C, get_affection_level
from game_state import fmt, fmt_min
from data_bridge import get_dashboard_stats

# ── 中文字型設定（對應 plot_manager 設定方式）────────────────
_FONTS = ['Microsoft JhengHei', 'PingFang TC', 'Arial Unicode MS', 'sans-serif']
plt.rcParams['font.sans-serif'] = _FONTS
plt.rcParams['axes.unicode_minus'] = False
try:
    sns.set_theme(style="whitegrid", font=_FONTS[0])
except Exception:
    pass


def build_stat_page(stat_frame, state):
    for w in stat_frame.winfo_children():
        w.destroy()

    # ── 取資料 ─────────────────────────────────────────────
    uid  = getattr(state, 'user_id', None)
    data = get_dashboard_stats(uid) if uid else {
        "core_stats": {}, "pie_chart": [], "bar_chart": [],
        "distraction_chart": [], "recent_sessions": []
    }
    cs = data["core_stats"]

    # ── 可捲動外層 ─────────────────────────────────────────
    outer = tk.Frame(stat_frame, bg=C["bg"])
    outer.pack(fill="both", expand=True)
    cv  = tk.Canvas(outer, bg=C["bg"], highlightthickness=0)
    sb  = tk.Scrollbar(outer, orient="vertical", command=cv.yview)
    cv.configure(yscrollcommand=sb.set)
    sb.pack(side="right", fill="y")
    cv.pack(side="left", fill="both", expand=True)
    inner = tk.Frame(cv, bg=C["bg"])
    win   = cv.create_window((0, 0), window=inner, anchor="nw")
    inner.bind("<Configure>", lambda e: cv.configure(
        scrollregion=cv.bbox("all")))
    cv.bind("<Configure>", lambda e: cv.itemconfig(win, width=e.width))
    cv.bind_all("<MouseWheel>", lambda e: cv.yview_scroll(
        int(-1 * (e.delta / 120)), "units"))

    # ── 頁首 ───────────────────────────────────────────────
    tk.Label(inner, text="📊  學習統計",
             font=("Georgia", 17, "bold"),
             bg=C["bg"], fg=C["text"]).pack(anchor="w", padx=20, pady=(18, 4))
    lvl = get_affection_level(state.affection)
    tk.Label(inner, text=f"{lvl['name']}　好感度 {state.affection:.0f}",
             font=("Helvetica Neue", 11),
             bg=C["bg"], fg=C["pink_text"]).pack(anchor="w", padx=20)

    # ── 核心數字卡片列 ─────────────────────────────────────
    def stat_card(parent, icon, label, value):
        f = tk.Frame(parent, bg=C["surface"],
                     highlightbackground=C["border"], highlightthickness=1)
        f.pack(side="left", expand=True, fill="both", padx=5)
        tk.Label(f, text=icon, font=("Helvetica Neue", 18),
                 bg=C["surface"], fg=C["pink"]).pack(pady=(12, 2))
        tk.Label(f, text=value, font=("Helvetica Neue", 15, "bold"),
                 bg=C["surface"], fg=C["text"]).pack()
        tk.Label(f, text=label, font=("Helvetica Neue", 9),
                 bg=C["surface"], fg=C["text3"]).pack(pady=(0, 12))

    total_secs = cs.get("total_hours", 0)
    avg_secs   = cs.get("avg_duration", 0)

    row1 = tk.Frame(inner, bg=C["bg"])
    row1.pack(fill="x", padx=15, pady=(16, 6))
    stat_card(row1, "⏱", "累積讀書", fmt(total_secs))
    stat_card(row1, "📅", "總次數",   f"{cs.get('session_count', 0)} 次")
    stat_card(row1, "📈", "平均時長", fmt(avg_secs))
    stat_card(row1, "🔥", "最長紀錄", fmt(cs.get("max_duration", 0)))

    row2 = tk.Frame(inner, bg=C["bg"])
    row2.pack(fill="x", padx=15, pady=(0, 14))
    stat_card(row2, "✅", "零干擾次數",  f"{cs.get('perfect_sessions', 0)} 次")
    stat_card(row2, "🛑", "總干擾次數",  f"{cs.get('total_distraction_count', 0)} 次")
    stat_card(row2, "⭐", "總 EXP",     f"{cs.get('total_exp', 0):.0f}")
    stat_card(row2, "💕", "今日好感",   f"+{state.daily_aff_gained:.1f}")

    # ── 輔助：嵌入圖表到 tkinter ───────────────────────────
    def embed_chart(fig, parent, pady=(0, 18)):
        chart_cv = FigureCanvasTkAgg(fig, master=parent)
        chart_cv.draw()
        chart_cv.get_tk_widget().pack(fill="x", padx=15, pady=pady)
        plt.close(fig)

    # ── 1. 最近 5 次專注時長長條圖（組員設計）──────────────
    recent = data["recent_sessions"]
    if recent:
        tk.Label(inner, text="⏰  最近 5 次專注時長趨勢",
                 font=("Georgia", 13, "bold"),
                 bg=C["bg"], fg=C["text"]).pack(anchor="w", padx=20, pady=(4, 2))

        import pandas as pd
        df_r = pd.DataFrame(recent)
        df_r['actual_duration'] = df_r['actual_duration'] / 60   # 秒→分
        df_r['display_time']    = pd.to_datetime(
            df_r['start_time']).dt.strftime('%m/%d %H:%M')

        fig1, ax1 = plt.subplots(figsize=(5.5, 3))
        sns.barplot(x='display_time', y='actual_duration',
                    hue='display_time', legend=False,
                    data=df_r, palette='Blues_r', ax=ax1)
        for p in ax1.patches:
            h = p.get_height()
            if h > 0:
                ax1.annotate(f"{h:.0f} 分",
                    (p.get_x() + p.get_width() / 2., h),
                    ha='center', va='bottom', xytext=(0, 4),
                    textcoords='offset points', fontsize=9)
        ax1.set_title("最近 5 次專注時長趨勢圖",
                      fontsize=12, fontweight='bold', pad=10)
        ax1.set_xlabel("讀書開始時間", fontsize=9)
        ax1.set_ylabel("實際專注時間（分鐘）", fontsize=9)
        ax1.tick_params(axis='x', labelsize=8)
        fig1.tight_layout()
        embed_chart(fig1, inner)
    else:
        tk.Label(inner, text="尚無讀書紀錄，無法繪製時長趨勢圖",
                 font=("Helvetica Neue", 11), bg=C["bg"], fg=C["text3"]
                 ).pack(pady=8)

    # ── 2. 各科目時間分配圓餅圖（組員設計）─────────────────
    pie_data = data["pie_chart"]
    if pie_data:
        tk.Label(inner, text="📚  各科目時間分配比例",
                 font=("Georgia", 13, "bold"),
                 bg=C["bg"], fg=C["text"]).pack(anchor="w", padx=20, pady=(4, 2))

        import pandas as pd
        df_p   = pd.DataFrame(pie_data)
        colors = ['#ff9999', '#66b3ff', '#99ff99',
                  '#ffcc99', '#c2c2f0', '#ffb3e6']
        fig2, ax2 = plt.subplots(figsize=(5, 4))
        ax2.pie(
            df_p['total_duration'],
            labels   = df_p['label_name'],
            autopct  = '%1.1f%%',
            startangle = 140,
            colors   = colors[:len(df_p)],
            textprops= {'fontsize': 10},
            wedgeprops= {'edgecolor': 'white', 'linewidth': 1.5}
        )
        ax2.set_title("各科目時間分配比例",
                      fontsize=12, fontweight='bold', pad=10)
        fig2.tight_layout()
        embed_chart(fig2, inner)
    else:
        tk.Label(inner, text="尚無標籤數據，無法繪製科目圖",
                 font=("Helvetica Neue", 11), bg=C["bg"], fg=C["text3"]
                 ).pack(pady=8)

    # ── 3. 干擾類型圓餅圖（組員設計）───────────────────────
    dist_data = data["distraction_chart"]
    if dist_data:
        tk.Label(inner, text="🛑  干擾時間比例（時間小偷分析）",
                 font=("Georgia", 13, "bold"),
                 bg=C["bg"], fg=C["text"]).pack(anchor="w", padx=20, pady=(4, 2))

        import pandas as pd
        df_d   = pd.DataFrame(dist_data)
        colors = ['#ff6b6b', '#feca57', '#ff9f43', '#ffff81', '#ee5253']
        fig3, ax3 = plt.subplots(figsize=(5, 4))
        ax3.pie(
            df_d['total_duration'],
            labels    = df_d['type_name'],
            autopct   = '%1.1f%%',
            startangle= 140,
            colors    = colors[:len(df_d)],
            textprops = {'fontsize': 10},
            wedgeprops= {'edgecolor': 'white', 'linewidth': 1.5}
        )
        ax3.set_title("干擾時間比例（時間小偷分析）",
                      fontsize=12, fontweight='bold', pad=10)
        fig3.tight_layout()
        embed_chart(fig3, inner)
    else:
        tk.Label(inner, text="目前沒有干擾紀錄，表現很好！🎉",
                 font=("Helvetica Neue", 11), bg=C["bg"], fg=C["text3"]
                 ).pack(pady=8)

    # ── 底部留白 ───────────────────────────────────────────
    tk.Frame(inner, bg=C["bg"], height=20).pack()
